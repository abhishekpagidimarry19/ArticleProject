package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.ArticleService;
import com.example.model.Article;
import com.simplilearn.entity.User;

@RestController
@RequestMapping("/api/articles")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @PostMapping("/create")
    public ResponseEntity<Article> createArticle(@RequestBody Article article) {
    	System.out.println("hello");
        Article createdArticle = articleService.createArticle(article);
        return new ResponseEntity<>(createdArticle, HttpStatus.CREATED);
    }

//    @PutMapping("/update/{slug}")
//    public  ResponseEntity<Article>updateArticle(@PathVariable String slug, @RequestBody Article updatedArticle) {
//       System.out.println("hello");
//    	Article updated = articleService.updateArticle(slug, updatedArticle);
//        if (updated != null) {
//            return new ResponseEntity<>(updated, HttpStatus.OK);
//        }
//        return new ResponseEntity<>(HttpStatus.NOT_FOUND);    
//    	
//    }
    


    @PutMapping("/update/{id}")
      public Article updateById(@PathVariable String slug,@RequestBody Article  updatedArticle) {
    	Article dbUser = articleService.findBySlug(slug);
        
          if (dbUser != null) {
              dbUser.setTitle(updatedArticle.getTitle());
              dbUser.setDescription(slug);
              dbUser.setBody(updatedArticle.getBody());
              
              return Article; 
             
          }
         
      }


    @GetMapping("/{slug}")
    public ResponseEntity<Article> getArticleBySlug(@PathVariable String slug) {
        Article article = articleService.getArticleBySlug(slug);
        if (article != null) {
            return new ResponseEntity<>(article, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{slug}")
    public ResponseEntity<Void> deleteArticleBySlug(@PathVariable String slug) {
        articleService.deleteArticleBySlug(slug);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/{slug}/time-to-read")
    public ResponseEntity<Integer> calculateTimeToRead(@PathVariable String slug,
                                                       @RequestParam(name = "speed", defaultValue = "200") int averageHumanSpeed) {
        int timeToRead = articleService.calculateTimeToRead(slug, averageHumanSpeed);
        return new ResponseEntity<>(timeToRead, HttpStatus.OK);
    }
}
package com.example.Service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Article;
import com.exmple.Repository.ArticleRepository;

@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleRepository articleRepository;

    @Override
    public Article createArticle(Article article) {
        // Basic validation
        if (article.getTitle() == null || article.getTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("Article title cannot be empty");
        }

        if (((String) article.getContent()).matches(".*<[^>]+>.*")) {
            throw new IllegalArgumentException("Article content cannot contain HTML tags");
        }

        // Your existing logic for setting slug and createdAt
        article.setSlug(generateSlug(article.getTitle()));
        article.setCreatedAt(new Date(0, 0, 0));

        // Save the article
        return articleRepository.save(article);
    }


    @Override
    public Article updateArticle(String slug, Article updatedArticle) {
        Article existingArticle = articleRepository.findBySlug(slug);
        if (existingArticle != null) {
            // Update fields if provided
            if (updatedArticle.getTitle() != null) {
                existingArticle.setTitle(updatedArticle.getTitle());
            }
            if (updatedArticle.getContent() != null) {
                existingArticle.setDescription(updatedArticle.getContent());
            }
            // Update the slug if needed
            existingArticle.setSlug(generateSlug(existingArticle.getTitle()));
            return articleRepository.save(existingArticle);
        }
        return null; // Article not found
    }

    @Override
    public Article getArticleBySlug(String slug) {
        return articleRepository.findBySlug(slug);
    }

    @Override
    public void deleteArticleBySlug(String slug) {
        Article article = articleRepository.findBySlug(slug);
        if (article != null) {
            articleRepository.delete(article);
        }
    }

    @Override
    public int calculateTimeToRead(String slug, int averageHumanSpeed) {
        // Implement your logic to calculate time to read based on article content length
        // and average human reading speed
        return 0; // Placeholder, replace with your calculation
    }

    private String generateSlug(String title) {
        // Implement your logic to generate a slug from the article title
        // This could involve removing spaces, converting to lowercase, etc.
        return title.replaceAll("\\s+", "-").toLowerCase();
    }
}
package com.example.Service;

import com.example.model.Article;

public interface ArticleService {
    Article createArticle(Article article);

    Article updateArticle(String slug, Article updatedArticle);

    Article getArticleBySlug(String slug);

    void deleteArticleBySlug(String slug);

    int calculateTimeToRead(String slug, int averageHumanSpeed);

	Article updateArticle(int slug);

	Article findBySlug(String slug);
}
